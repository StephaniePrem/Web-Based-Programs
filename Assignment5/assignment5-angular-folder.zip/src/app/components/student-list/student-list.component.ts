import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.css']
})
export class StudentListComponent implements OnInit {
  items: any;
  selectedItem ={};
  constructor(private dataService: DataService) { }

  ngOnInit(): void {
    // call our express API to get some data
    this.items = this.dataService.get('/student');
  }

  editItem(item: any){
    this.selectedItem= item;
    
  }
  deleteItem(item: any){
    this.dataService.remove('/student/'+ item._id)
    .subscribe(() => this.items = this.dataService.get('/student'));
  }

}


