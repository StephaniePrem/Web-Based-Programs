import { Component, Input, OnInit } from '@angular/core';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-student-edit',
  templateUrl: './student-edit.component.html',
  styleUrls: ['./student-edit.component.css']
})
export class StudentEditComponent implements OnInit {

  @Input() student: any = {};

  constructor(private dataServce: DataService) { }

  ngOnInit(): void {

  }

  save() { 
    if (this.student._id){
      this.dataServce.post(`/student/${this.student._id}`, this.student).subscribe(result => {
        console.log(result);
      });
    }
    else{
      this.dataServce.post('/student', this.student).subscribe(result => {
        console.log(result);
      });
    }
  
  }

}
