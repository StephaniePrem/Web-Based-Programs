import Students from "./components/Students";


const App = (props) => {
  return (
    <main>
      <Students />
    </main>
  )
}

export default App;
