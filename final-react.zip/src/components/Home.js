import React from 'react';

const Home = () => {
    return (
        <div>
            <main><section>
                <h1>Confirmation</h1>
                <p>Thank you for your interest in our workshops!
                    A member of our team will reach out soon.
                </p>
            </section></main>
        </div>
    );
}

export default Home;