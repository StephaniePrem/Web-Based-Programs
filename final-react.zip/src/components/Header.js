
import Menu from './Menu';

const Header = () => (
    <header>
        <div className="title">
            <h1>Request More Information!</h1>
        </div>
        <div className="sub-title">
            <Menu tagline="Welcome! COSC 484 Term Project" />
            <div className="clearfix"></div>
        </div>
    </header>

);

export default Header;


