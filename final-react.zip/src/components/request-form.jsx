import { useHistory, useLocation } from 'react-router-dom';
import axios from 'axios';
// import moment from 'moment';

import { nodemailer, callback, userTokens, createTransport } from 'nodemailer';


const RequestForm = () => {
    const apiUrl = 'http://localhost:3030/student/';

    const location = useLocation();
    const history = useHistory();
    let student = {};
    if (location.state) {
        student = { ...location.state };
    }


    const valEmail = () => {
        // let transporter = {};
        // if (location.state) {
        //     transporter = nodemailer.createTransport({
        //         host: 'smtp.gmail.com',
        //         port: 465,
        //         secure: true,
        //         auth: {
        //             type: 'OAuth2',
        //             user: student.email.value
        //         }
        //     });
        // }
        // let accessToken = {};
        // if (location.state) {
        //     accessToken = userTokens[transporter];
        //     if (!accessToken) {
        //         return callback(new Error('Invalid Email'));
        //     } else {
        //         return callback(null, accessToken);
        //     }
        // }
    }

    const save = async (e) => {

        e.preventDefault();
        const { firstname, lastname, email, phoneNum, campus, workshop } = e.target.elements;

        const payload = {
            ...student,
            firstname: firstname.value,
            lastname: lastname.value,
            email: email.value,
            phoneNum: phoneNum.value,
            campus: campus.value,
            workshop: workshop.value
        };
        await axios.post(apiUrl + student._id, payload);
        history.push('/');

        // let transporter = {};
        // if (location.state) {
        //     transporter = nodemailer.createTransport({
        //         host: 'smtp.gmail.com',
        //         port: 465,
        //         secure: true,
        //         auth: {
        //             user: student.email
        //         }
        //     });
        // }
        // let mailOptions = {
        //     from: '"Stephanie Prem" <nodemailertowson@gmail.com>',
        //     to: student.email,
        //     subject: 'Confirmation',
        //     text: 'Your information has been recieved!',
        //     html: '<p> Your information has been recieved! </p>'
        // };
        // transporter.sendMail(student[mailOptions, callback]);
        window.open('mailto:test@example.com');
    };
    return (
        <main><section>
            <div className="page-header">
                <h2>Enter Your Information Below</h2>
            </div>
            <form onSubmit={save}>
                <div className="row">
                    <div className="col-md-4">
                        <div className="mb-3">
                            <label htmlFor="firstname"> First Name</label>
                            <input className="form-control input-lg" defaultvalue={student.firstname} type="text" id="firstname" name="firstname" required />
                        </div>

                        <div className="mb-3">
                            <label htmlFor="lastname"> Last Name</label>
                            <input className="form-control input-lg" defaultvalue={student.lastname} type="text" id="lastname" name="lastname" required />
                        </div>
                        <div className="mb-3">
                            <label htmlFor="campus"> Which campus are you interested in?</label>
                            <select className="form-control input-lg" defaultvalue={student.campus} id="campus" name="campus" required >
                                <option>Main Campus</option>
                                <option>West Campus</option>
                                <option>East Campus</option>
                                <option>North Campus</option>
                                <option>South Campus</option>
                            </select>
                        </div>
                    </div>

                    <div className="col-md-4">
                        <div className="mb-3">
                            <label htmlFor="email"> Email</label>
                            <input className="form-control input-lg" defaultvalue={student.email} type="text" id="email" name="email" required onChange={valEmail} />
                        </div>
                        <div className="mb-3">
                            <label htmlFor="phoneNum"> Phone Number</label>
                            <input className="form-control input-lg" defaultvalue={student.phoneNum} type="text" id="phoneNum" name="phoneNum" required />
                        </div>
                        <div className="mb-3">
                            <label htmlFor="workshop"> Which workshop would you like to learn more about?</label>
                            <input className="form-control input-lg" defaultvalue={student.workshop} type="text" id="workshop" name="workshop" />
                        </div>
                    </div>


                </div>

                <div className="mb-3">
                    <button onClick={() => history.replace('/')} className="btn btn-secondary me-3">Cancel</button>
                    {/* <button className="btn btn-secondary px-3" type="reset"> Clear</button> */}
                    <button className="btn btn-primary ms-3" type="submit" > Save</button>
                </div>
            </form>
        </section> </main>);
}


export default RequestForm;