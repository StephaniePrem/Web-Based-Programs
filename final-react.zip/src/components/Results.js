import React from 'react';
const ResultsCon = () => {
    return (
        <div>
            <main><section>
                <p>
                    Thank you for your interest in our workshops!
                    A member of our team will reach out soon.
                </p>
            </section></main>
        </div>
    );
}

export default ResultsCon;
