const Page = ({ children }) => {
    return (
        <div>
            <main>
                <section>
                    {children}
                </section>
            </main>
        </div>
    )
}

export default Page;
