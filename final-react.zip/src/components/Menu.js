import React from 'react';
import {NavLink} from 'react-router-dom';


function Menu(props) {
    return (
        <nav className="top-menu">
            <ul>
                
                <li><NavLink exact={true} activeClassName='active' to='/request-info'>Request Info</NavLink></li>
                <li ><NavLink exact={true} activeClassName='active' to='/admissions' >Admissions</NavLink></li>
                <li><NavLink exact={true} activeClassName='active' to='/'>Confirmation</NavLink></li>
                {/* <li><NavLink exact={true} activeClassName='active' to='/home'>Home</NavLink></li> */}
                <li className="tagline">{ props.tagline }</li>
            </ul>
        </nav>
    );
}

export default Menu;


