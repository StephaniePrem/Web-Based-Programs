// import React, { Component } from 'react';
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import moment from 'moment';
import { Link } from 'react-router-dom';


const Students = (props) => {
    const [data, setStudents] = useState([]);
    const baseUrl = 'http://localhost:3030/student/';

    useEffect(() => {
        axios.get(baseUrl, { responseType: 'json' })
            .then(result => setStudents(result.data))
            .catch(err => console.log('Error fetching data: ', err));
    }, []);

    const edit = (student) => {
        console.log('You are ediiting: ', student);
    };

    const deleteItem = async (student) => {
        setStudents(data.filter(item => item._id !== student._id));
        await axios.delete(baseUrl + student._id);
    };

    const completedR =  (student) => {
        // setStudents(data.filter(item => item.completed === "Done"));
        return student.completed='Done';
        
    };

    return (
        <main><section>
            <table className="table">
                <tbody>
                    {data.map((student, index) => (
                        <tr key={index}>
                            <td>{index + 1}</td>
                            <td>{student.firstname}</td>
                            <td>{student.lastname}</td>
                            <td>{student.email}</td>
                            <td>{student.phoneNum}</td>
                            <td>{student.campus}</td>
                            <td>{student.workshop}</td>
                            <td>{moment(student.dateS).format('MMMM Do YYYY, h:mm:ss a')} </td>
                            <td>{student.completed} </td>
                            {/* <td>
                                <div>
                                    <label>
                                        <Checkbox
                                            // checked={this.state.completed}
                                            onChange={this.completedR}
                                        />
                                        <span>Label Text</span>
                                    </label>
                                </div>
                            </td> */}
                            <td>
                                <Link className="btn btn-sm btn-primary" to={{
                                    pathname: "/request-info",
                                    state: {
                                        student: student,
                                    },
                                }}>
                                    Edit
                                </Link>
                                {/* <button className="btn btn-sm btn-primary me-2" onClick={() => edit(student)}>Edit</button> */}
                                <button className="btn btn-sm btn-danger ms-2" onClick={() => deleteItem(student)}>Delete</button>
                                <button type="checkbox" className="btn btn-warning ms-2" onClick={() => completedR(student)}>Completed</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </section></main>
    )
}

export default Students;
