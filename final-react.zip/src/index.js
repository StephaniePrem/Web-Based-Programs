import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Route } from 'react-router-dom';
import Header from './components/Header';
import RequestForm from "./components/request-form.jsx";
import ResultsCon from './components/Results';
import Home from './components/Home';
import Students from "./components/Students";

ReactDOM.render(
  <BrowserRouter>
    <React.Fragment>
      <Route path='/' component={Header} />
      <Route path="/" component={Home} exact />
      <Route path="/request-info" component={RequestForm} exact />
      <Route path="/admissions" component={Students} exact />
      <Route exact path="/confirmation" componenet={ResultsCon} />
    </React.Fragment>
  </BrowserRouter>,
  document.getElementById('root'));
