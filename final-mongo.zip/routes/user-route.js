const express = require('express');
const router = express.Router();

const Student = require('../models/student-model');

router.get('/', async (req, res) => { // promise 

    const users = await Student.find();
    res.statusCode(200).json(users);

    // res.send('You are on the home page for students');
});

router.get('/:userid', (req, res) => {
    const id = req.params.studentId;

    res.send('You want to get a record for student with ID: ' + id);
});

// add student
router.post('/', async (req, res) => {
    const student = new Student({
        fname: req.body.firstname,
        lname: req.body.lastname,
        email: req.body.email,
        campus: req.body.campus,
        workshop: req.body.workshop
    });

    try {
        const result = await student.save();
        res.json(result);
    } catch (err) {
        res.json({ message: err })
    }
});

//update endpoint/student
router.post('/:id', async (req, res) => {
    const student = {
        fname: req.body.firstname,
        lname: req.body.lastname,
        email: req.body.email,
        campus: req.body.campus,
        workshop: req.body.workshop
    };
    try {
        const result = await Student.findByIdAndUpdate(req.params.id, student, { new: true} );
        res.json(result);   
    } catch (err) {
        res.json({ message: err });
    }
});

// delete endpoint route
router.delete('/:id', async (req, res) => {
    try {
        const result = await Student.findByIdAndDelete(req.params.id);
        res.json(result);
    } catch (err) {
        res.json({ message: err })
    }
});
module.exports = router;