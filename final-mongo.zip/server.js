const express = require('express');
const app = express();
const PORT = 3030;

// const bodyParser = require('body-parser');
const mongoose = require('mongoose');

// const url = require('url');
const cors = require('cors');

const studentRoutes = require('./routes/student-route');
const userRoutes = require('./routes/student-route');

// middleware
app.use(cors());
//app.use(bodyParser.json());
app.use(express.json());
app.use(express.urlencoded({
    extended: true
}));

app.use('/student', studentRoutes);
app.use('/user', userRoutes);

app.get('/', (req, res) => {
    res.send('You are on the default page!');
});

// connect to database
mongoose.connect(
    // 'mongodb+srv://db_user1:whaTdOI2@cluster0.qrnfk.mongodb.net/db',
    'mongodb+srv://db_user1:whaTdOI2@cluster0.qrnfk.mongodb.net/db?retryWrites=true&w=majority',
    { useNewUrlParser: true, useUnifiedTopology: true, useFindAndModify: false })
    .then(() => console.log('connected to the database successfully!'))
    .catch(err => console.error('Error connecting to DB', err.message));

app.listen(PORT, () => console.log(`server is running at http://localhost:${PORT}`));