import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  private baseUrl = 'http://localhost:3030';

  constructor(private http: HttpClient) { }

  get(endpoint: string){
    return this.http.get(this.baseUrl + endpoint);
  }

  post(endpoint: string, payload: any){
    return this.http.post(this.baseUrl + endpoint, payload);
  }

  remove(endpoint: string){
    return this.http.delete(this.baseUrl +endpoint);
  }
}
