const mongoose = require('mongoose');

const StudentSchema = mongoose.Schema({
    firstname:{
        type: String,
        required: true
    },
    lastname:{
        type: String,
        required: true
    },
    email:{
        type: String,
        required: true
    },
    phoneNum:{
        type: String,
        required: true
    },
    campus:{
        type: String,
        required: true
    },
    workshop:{
        type: String
    }
});

module.exports = mongoose.model('Students', StudentSchema);